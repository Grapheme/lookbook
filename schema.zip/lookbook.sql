-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 24 2015 г., 15:02
-- Версия сервера: 5.5.25
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `lookbook`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
`id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(1, 2, 'dictionaries', 'view', 1),
(2, 2, 'dictionaries', 'create', 1),
(3, 2, 'dictionaries', 'edit', 1),
(4, 2, 'dictionaries', 'delete', 1),
(5, 2, 'dictionaries', 'dicval_view', 1),
(6, 2, 'dictionaries', 'dicval_create', 1),
(7, 2, 'dictionaries', 'dicval_edit', 1),
(8, 2, 'dictionaries', 'dicval_delete', 1),
(9, 2, 'dictionaries', 'dicval_restore', 1),
(10, 2, 'dictionaries', 'settings', 1),
(11, 2, 'dictionaries', 'dicval_entity_view', 1),
(12, 2, 'dictionaries', 'hidden', 1),
(13, 2, 'dictionaries', 'import', 1),
(14, 2, 'galleries', 'view', 1),
(15, 2, 'galleries', 'create', 1),
(16, 2, 'galleries', 'edit', 1),
(17, 2, 'galleries', 'delete', 1),
(18, 2, 'pages', 'view', 1),
(19, 2, 'pages', 'create', 1),
(20, 2, 'pages', 'edit', 1),
(21, 2, 'pages', 'delete', 1),
(22, 2, 'pages', 'advanced', 1),
(23, 2, 'pages', 'page_restore', 1),
(24, 2, 'seo', 'edit', 1),
(25, 2, 'system', 'system', 1),
(26, 2, 'system', 'modules', 1),
(27, 2, 'system', 'groups', 1),
(28, 2, 'system', 'users', 1),
(29, 2, 'system', 'locale_editor', 1),
(30, 2, 'system', 'tpl_editor', 1),
(31, 2, 'system', 'menu_editor', 1),
(32, 2, 'uploads', 'view', 1),
(33, 2, 'uploads', 'create', 1),
(34, 2, 'uploads', 'delete', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
`id` int(10) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `settings` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_textfields_values`
--

DROP TABLE IF EXISTS `dictionary_textfields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_textfields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
`id` int(10) unsigned NOT NULL,
  `version_of` int(10) unsigned DEFAULT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_parent_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_child_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_parent_field` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'developer', 'Разработчики', 'admin', '', '2015-03-05 11:22:36', '2015-03-05 11:22:36'),
(2, 'admin', 'Администраторы', 'admin', '', '2015-03-05 11:22:36', '2015-03-17 08:31:18'),
(3, 'moderator', 'Модераторы', 'admin', '', '2015-03-05 11:22:36', '2015-03-05 11:22:36'),
(4, 'blogger', 'Блогер', 'blogger', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1),
('2015_03_17_143929_create_password_reminders_table', 2),
('2014_06_18_174055_install_ulogin', 3),
('2015_03_24_075501_add_users_fields', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'dictionaries', 1, 0, '2015-03-05 11:22:37', '2015-03-05 11:22:37'),
(2, 'pages', 1, 1, '2015-03-05 11:22:37', '2015-03-05 11:22:37'),
(3, 'galleries', 1, 2, '2015-03-05 11:22:37', '2015-03-05 11:22:37'),
(4, 'seo', 1, 3, '2015-03-05 11:22:37', '2015-03-05 11:22:37'),
(5, 'catalog', 1, 4, '2015-03-05 11:22:38', '2015-03-05 11:22:38'),
(6, 'system', 1, 127, '2015-03-05 11:22:38', '2015-03-05 11:22:38'),
(7, 'uploads', 1, 0, '2015-03-17 08:30:40', '2015-03-17 08:30:40');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
`id` int(10) unsigned NOT NULL,
  `version_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `in_menu` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `version_of`, `name`, `slug`, `template`, `type_id`, `publication`, `start_page`, `in_menu`, `order`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Главная страница', 'glavnaya-stranica', 'index', NULL, 1, 1, NULL, NULL, '2015-03-17 08:37:17', '2015-03-17 08:37:17');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
`id` int(10) unsigned NOT NULL,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `pages_meta`
--

INSERT INTO `pages_meta` (`id`, `page_id`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', NULL, '2015-03-17 08:37:17', '2015-03-17 08:37:17'),
(2, 1, 'en', NULL, '2015-03-17 08:37:17', '2015-03-17 08:37:17');

-- --------------------------------------------------------

--
-- Структура таблицы `password_reminders`
--

DROP TABLE IF EXISTS `password_reminders`;
CREATE TABLE IF NOT EXISTS `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '999',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `module`, `unit_id`, `language`, `title`, `description`, `keywords`, `url`, `h1`, `created_at`, `updated_at`) VALUES
(1, 'Page', 1, 'ru', 'Главная страница', '', '', NULL, '', '2015-03-17 08:37:17', '2015-03-17 08:37:17'),
(2, 'Page', 1, 'en', '', '', '', NULL, '', '2015-03-17 08:37:18', '2015-03-17 08:37:18');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('3c8c5934c82b9a7de961c6c47280679ec139c6bc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibGNEVjRtZnczb2hudFFvOHBMR0ZOTnI3TGY1bHZsYUN6QTdBclZPZyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQyNzE5NDkyMjtzOjE6ImMiO2k6MTQyNzE4MDg0NjtzOjE6ImwiO3M6MToiMCI7fX0=', 1427194923);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `module`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, '', 'language', 'ru', '2015-03-05 11:22:36', '2015-03-05 11:22:36');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ulogin`
--

DROP TABLE IF EXISTS `ulogin`;
CREATE TABLE IF NOT EXISTS `ulogin` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `network` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `identity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `nickname` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `photo_big` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `bdate` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `sex` tinyint(4) NOT NULL,
  `profile` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `uid` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `token_secret` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `verified_email` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `ulogin`
--

INSERT INTO `ulogin` (`id`, `user_id`, `network`, `identity`, `email`, `first_name`, `last_name`, `nickname`, `country`, `city`, `photo`, `photo_big`, `bdate`, `sex`, `profile`, `uid`, `access_token`, `token_secret`, `verified_email`, `created_at`, `updated_at`) VALUES
(1, 8, 'vkontakte', 'http://vk.com/id165874961', 'vkharseev@gmail.com', 'Александр', 'Новиков', '', '', '', 'http://cs303300.vk.me/v303300961/5d35/vpJsezP4Y6w.jpg', 'http://cs303300.vk.me/v303300961/5d33/COCSYUH3JUs.jpg', '', 0, 'http://vk.com/id165874961', '', '', '', 0, '2015-03-19 04:50:48', '2015-03-19 04:50:48'),
(2, 8, 'facebook', 'http://www.facebook.com/100001912017351', 'vkharseev@gmail.com', 'Владимир', 'Харсеев', '', '', '', 'http://graph.facebook.com/100001912017351/picture?type=square', 'http://graph.facebook.com/100001912017351/picture?type=large', '', 0, 'http://www.facebook.com/100001912017351', '', '', '', 0, '2015-03-19 04:51:25', '2015-03-19 04:51:25');

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
`id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `brand` tinyint(1) unsigned DEFAULT '0',
  `about` text COLLATE utf8_unicode_ci,
  `blogpicture` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blogname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inspiration` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `links` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_login` tinyint(1) unsigned DEFAULT '1',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `brand`, `about`, `blogpicture`, `blogname`, `phone`, `inspiration`, `site`, `links`, `location`, `birth`, `first_login`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Разработчик', '', 'developer@grapheme.ru', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '$2y$10$LH9T7AASamunuxhHJ6vxAePpzrr5yk7gqAVSh5knWl7iDHSj4tgEy', '', '', '', 0, 'TNXsXwFuNHhCbonoszYNBud9s3XOGo4GUZuxcbYa4db50qg7szeUXr1Uxkvv', '2015-03-05 11:22:36', '2015-03-17 08:31:41'),
(2, 2, 'Администратор', '', 'admin@grapheme.ru', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '$2y$10$.UqXu9kcBK7FwHPp/OnkNOGDEilOK/OzRaXMNDTAq3Ln4vAWUiRqi', '', '', '', 0, 'Z6nZu4J8AfQzHoMsJglDt2q4esMU9aHT6aXFETdYWzOcd0pzkG3JWmyNt6pE', '2015-03-05 11:22:36', '2015-03-17 09:17:29'),
(3, 3, 'Модератор', '', 'moder@grapheme.ru', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '$2y$10$G3LBoWa2GyjUcu6qUotmQ.wmnJqqoutaSa2ozj/GkBat6udI.IXIK', '', '', '', 0, NULL, '2015-03-05 11:22:36', '2015-03-05 11:22:36'),
(8, 4, 'Владимир', 'Харсеев', 'vkharseev@gmail.com', 1, 0, 'Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.', '', 'Мой блог', '8(919)8919721', '', 'grapheme.ru', '', 'г.Ростов-на-Дону', '24.05.2014', 0, '$2y$10$snEniafeiTpc76SzRBW62.WVXvoJzvV.wS4UjHpyGGvz1TsLDtAyu', 'uploads/users/1427194899_8_1874.png', 'uploads/users/thumbnail/thumb_1427194899_8_1874.png', NULL, NULL, 'QdBO2clbydItNOndkUPM9QPtUPEqfaSsZ9EIZCI5YdJaKiIQ1nblAREb3rzy', '2015-03-19 04:38:05', '2015-03-24 08:01:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
 ADD PRIMARY KEY (`id`), ADD KEY `actions_group_id_index` (`group_id`), ADD KEY `actions_module_index` (`module`), ADD KEY `actions_action_index` (`action`), ADD KEY `actions_status_index` (`status`);

--
-- Indexes for table `dictionary`
--
ALTER TABLE `dictionary`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `dictionary_slug_unique` (`slug`), ADD KEY `dictionary_name_index` (`name`), ADD KEY `dictionary_entity_index` (`entity`), ADD KEY `dictionary_view_access_index` (`view_access`), ADD KEY `dictionary_order_index` (`order`);

--
-- Indexes for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_fields_values_language_index` (`language`), ADD KEY `dictionary_fields_values_key_index` (`key`), ADD KEY `dictionary_fields_values_value_index` (`value`);

--
-- Indexes for table `dictionary_textfields_values`
--
ALTER TABLE `dictionary_textfields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_textfields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_textfields_values_language_index` (`language`), ADD KEY `dictionary_textfields_values_key_index` (`key`);

--
-- Indexes for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_version_of_index` (`version_of`), ADD KEY `dictionary_values_dic_id_index` (`dic_id`), ADD KEY `dictionary_values_slug_index` (`slug`), ADD KEY `dictionary_values_order_index` (`order`), ADD KEY `dictionary_values_lft_index` (`lft`), ADD KEY `dictionary_values_rgt_index` (`rgt`);

--
-- Indexes for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_values_meta_language_index` (`language`);

--
-- Indexes for table `dictionary_values_rel`
--
ALTER TABLE `dictionary_values_rel`
 ADD PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`), ADD KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_dic_id_index` (`dicval_parent_dic_id`), ADD KEY `dictionary_values_rel_dicval_child_dic_id_index` (`dicval_child_dic_id`), ADD KEY `dictionary_values_rel_dicval_parent_field_index` (`dicval_parent_field`(255));

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `groups_name_unique` (`name`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_version_of_index` (`version_of`), ADD KEY `pages_slug_index` (`slug`), ADD KEY `pages_type_id_index` (`type_id`), ADD KEY `pages_publication_index` (`publication`), ADD KEY `pages_start_page_index` (`start_page`), ADD KEY `pages_in_menu_index` (`in_menu`), ADD KEY `pages_order_index` (`order`);

--
-- Indexes for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_page_id_index` (`page_id`), ADD KEY `pages_blocks_slug_index` (`slug`), ADD KEY `pages_blocks_order_index` (`order`);

--
-- Indexes for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_meta_block_id_index` (`block_id`), ADD KEY `pages_blocks_meta_language_index` (`language`);

--
-- Indexes for table `pages_meta`
--
ALTER TABLE `pages_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_meta_page_id_index` (`page_id`), ADD KEY `pages_meta_language_index` (`language`);

--
-- Indexes for table `password_reminders`
--
ALTER TABLE `password_reminders`
 ADD KEY `password_reminders_email_index` (`email`), ADD KEY `password_reminders_token_index` (`token`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
 ADD PRIMARY KEY (`id`), ADD KEY `photos_gallery_id_index` (`gallery_id`), ADD KEY `photos_order_index` (`order`);

--
-- Indexes for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
 ADD PRIMARY KEY (`id`), ADD KEY `rel_mod_gallery_module_index` (`module`), ADD KEY `unit_id` (`module`);

--
-- Indexes for table `seo`
--
ALTER TABLE `seo`
 ADD PRIMARY KEY (`id`), ADD KEY `unit_id` (`module`), ADD KEY `seo_module_index` (`module`), ADD KEY `seo_unit_id_index` (`unit_id`), ADD KEY `seo_language_index` (`language`), ADD KEY `seo_url_index` (`url`(255));

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
 ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`module`), ADD KEY `settings_module_index` (`module`), ADD KEY `settings_name_index` (`name`);

--
-- Indexes for table `storages`
--
ALTER TABLE `storages`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`module`), ADD KEY `storages_module_index` (`module`), ADD KEY `storages_name_index` (`name`);

--
-- Indexes for table `ulogin`
--
ALTER TABLE `ulogin`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `ulogin_identity_unique` (`identity`), ADD KEY `ulogin_user_id_foreign` (`user_id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
 ADD PRIMARY KEY (`id`), ADD KEY `uploads_mime1_index` (`mime1`), ADD KEY `uploads_mime2_index` (`mime2`), ADD KEY `uploads_module_index` (`module`), ADD KEY `uploads_unit_id_index` (`unit_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `dictionary`
--
ALTER TABLE `dictionary`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_textfields_values`
--
ALTER TABLE `dictionary_textfields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_meta`
--
ALTER TABLE `pages_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `seo`
--
ALTER TABLE `seo`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `storages`
--
ALTER TABLE `storages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ulogin`
--
ALTER TABLE `ulogin`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `ulogin`
--
ALTER TABLE `ulogin`
ADD CONSTRAINT `ulogin_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
