-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 15 2015 г., 15:57
-- Версия сервера: 5.5.37
-- Версия PHP: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `lookbook`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `actions_group_id_index` (`group_id`),
  KEY `actions_module_index` (`module`),
  KEY `actions_action_index` (`action`),
  KEY `actions_status_index` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=79 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(32, 2, 'dictionaries', 'dicval_view', 1),
(33, 2, 'dictionaries', 'dicval_create', 1),
(34, 2, 'dictionaries', 'dicval_edit', 1),
(35, 2, 'dictionaries', 'dicval_delete', 1),
(36, 2, 'dictionaries', 'dicval_entity_view', 1),
(37, 2, 'galleries', 'create', 1),
(38, 2, 'galleries', 'edit', 1),
(39, 2, 'galleries', 'delete', 1),
(40, 2, 'pages', 'view', 1),
(41, 2, 'pages', 'create', 1),
(42, 2, 'pages', 'edit', 1),
(43, 2, 'pages', 'delete', 1),
(44, 2, 'pages', 'advanced', 1),
(45, 2, 'seo', 'edit', 1),
(46, 2, 'system', 'system', 1),
(47, 2, 'system', 'users', 1),
(48, 2, 'system', 'menu_editor', 1),
(49, 1, 'dictionaries', 'view', 1),
(50, 1, 'dictionaries', 'create', 1),
(51, 1, 'dictionaries', 'edit', 1),
(52, 1, 'dictionaries', 'delete', 1),
(53, 1, 'dictionaries', 'dicval_view', 1),
(54, 1, 'dictionaries', 'dicval_create', 1),
(55, 1, 'dictionaries', 'dicval_edit', 1),
(56, 1, 'dictionaries', 'dicval_delete', 1),
(57, 1, 'dictionaries', 'dicval_restore', 1),
(58, 1, 'dictionaries', 'settings', 1),
(59, 1, 'dictionaries', 'dicval_entity_view', 1),
(60, 1, 'dictionaries', 'hidden', 1),
(61, 1, 'dictionaries', 'import', 1),
(62, 1, 'galleries', 'create', 1),
(63, 1, 'galleries', 'edit', 1),
(64, 1, 'galleries', 'delete', 1),
(65, 1, 'pages', 'view', 1),
(66, 1, 'pages', 'create', 1),
(67, 1, 'pages', 'edit', 1),
(68, 1, 'pages', 'delete', 1),
(69, 1, 'pages', 'advanced', 1),
(70, 1, 'pages', 'page_restore', 1),
(71, 1, 'seo', 'edit', 1),
(72, 1, 'system', 'system', 1),
(73, 1, 'system', 'modules', 1),
(74, 1, 'system', 'groups', 1),
(75, 1, 'system', 'users', 1),
(76, 1, 'system', 'locale_editor', 1),
(77, 1, 'system', 'tpl_editor', 1),
(78, 1, 'system', 'menu_editor', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `settings` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dictionary_slug_unique` (`slug`),
  KEY `dictionary_name_index` (`name`),
  KEY `dictionary_entity_index` (`entity`),
  KEY `dictionary_view_access_index` (`view_access`),
  KEY `dictionary_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `dictionary`
--

INSERT INTO `dictionary` (`id`, `slug`, `name`, `entity`, `icon_class`, `hide_slug`, `make_slug_from_name`, `name_title`, `pagination`, `view_access`, `sort_by`, `sort_order_reverse`, `sortable`, `order`, `settings`, `created_at`, `updated_at`) VALUES
(1, 'categories', 'Категории', 1, 'fa-th-large', 1, NULL, NULL, 0, 0, NULL, 0, 1, 0, NULL, '2015-04-07 09:35:56', '2015-04-07 09:35:56'),
(2, 'tags', 'Теги', 1, 'fa-tags', 1, NULL, 'Текст', 0, 0, NULL, 0, 1, 0, NULL, '2015-04-07 09:35:56', '2015-04-07 09:35:56');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`),
  KEY `dictionary_fields_values_language_index` (`language`),
  KEY `dictionary_fields_values_key_index` (`key`),
  KEY `dictionary_fields_values_value_index` (`value`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `dictionary_fields_values`
--

INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 7, NULL, 'tags_id', '6', '2015-04-07 09:47:36', '2015-04-07 09:47:36'),
(2, 8, NULL, 'tags_id', '3', '2015-04-07 09:48:33', '2015-04-07 10:06:43'),
(3, 9, NULL, 'tags_id', '2', '2015-04-07 09:48:53', '2015-04-07 09:48:53');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_textfields_values`
--

DROP TABLE IF EXISTS `dictionary_textfields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_textfields_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_textfields_values_dicval_id_index` (`dicval_id`),
  KEY `dictionary_textfields_values_language_index` (`language`),
  KEY `dictionary_textfields_values_key_index` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_of` int(10) unsigned DEFAULT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_values_version_of_index` (`version_of`),
  KEY `dictionary_values_dic_id_index` (`dic_id`),
  KEY `dictionary_values_slug_index` (`slug`),
  KEY `dictionary_values_order_index` (`order`),
  KEY `dictionary_values_lft_index` (`lft`),
  KEY `dictionary_values_rgt_index` (`rgt`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `dictionary_values`
--

INSERT INTO `dictionary_values` (`id`, `version_of`, `dic_id`, `slug`, `name`, `order`, `lft`, `rgt`, `created_at`, `updated_at`) VALUES
(1, NULL, 2, NULL, 'TRENDS', NULL, 1, 2, '2015-04-07 09:45:39', '2015-04-07 09:47:13'),
(2, NULL, 2, NULL, 'STREETFASHION', NULL, 3, 4, '2015-04-07 09:45:58', '2015-04-07 09:45:59'),
(3, NULL, 2, NULL, 'DESIGNERS', NULL, 5, 6, '2015-04-07 09:46:18', '2015-04-07 09:46:18'),
(4, NULL, 2, NULL, 'MODELS', NULL, 7, 8, '2015-04-07 09:46:31', '2015-04-07 09:46:31'),
(5, NULL, 2, NULL, 'BRANDS', NULL, 9, 10, '2015-04-07 09:46:45', '2015-04-07 09:46:46'),
(6, NULL, 2, NULL, 'SHOPPING', NULL, 11, 12, '2015-04-07 09:47:00', '2015-04-07 09:47:00'),
(7, NULL, 1, NULL, 'FASHION', NULL, 1, 2, '2015-04-07 09:47:36', '2015-04-07 09:47:36'),
(8, NULL, 1, NULL, 'BEAUTY', NULL, 3, 4, '2015-04-07 09:48:33', '2015-04-07 10:06:43'),
(9, NULL, 1, NULL, 'LIFESTYLE', NULL, 5, 6, '2015-04-07 09:48:53', '2015-04-07 09:48:53');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`),
  KEY `dictionary_values_meta_language_index` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_parent_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_child_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_parent_field` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`),
  KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`),
  KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`),
  KEY `dictionary_values_rel_dicval_parent_dic_id_index` (`dicval_parent_dic_id`),
  KEY `dictionary_values_rel_dicval_child_dic_id_index` (`dicval_child_dic_id`),
  KEY `dictionary_values_rel_dicval_parent_field_index` (`dicval_parent_field`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `dictionary_values_rel`
--

INSERT INTO `dictionary_values_rel` (`dicval_parent_id`, `dicval_child_id`, `dicval_parent_dic_id`, `dicval_child_dic_id`, `dicval_parent_field`) VALUES
(7, 1, 1, 2, 'tags_id'),
(7, 2, 1, 2, 'tags_id'),
(7, 3, 1, 2, 'tags_id'),
(7, 4, 1, 2, 'tags_id'),
(7, 5, 1, 2, 'tags_id'),
(7, 6, 1, 2, 'tags_id'),
(8, 4, 1, 2, 'tags_id'),
(8, 5, 1, 2, 'tags_id'),
(8, 6, 1, 2, 'tags_id'),
(9, 2, 1, 2, 'tags_id'),
(9, 6, 1, 2, 'tags_id');

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `galleries`
--

INSERT INTO `galleries` (`id`, `name`, `settings`, `created_at`, `updated_at`) VALUES
(1, 'Пост - 1', '', '2015-04-15 09:03:50', '2015-04-15 09:03:50');

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'developer', 'Разработчики', 'admin', '', '2015-04-07 09:35:56', '2015-04-07 09:40:54'),
(2, 'admin', 'Администраторы', 'admin', '', '2015-04-07 09:35:56', '2015-04-07 09:40:31'),
(3, 'moderator', 'Модераторы', 'moderator', '', '2015-04-07 09:35:56', '2015-04-07 09:35:56'),
(4, 'blogger', 'Блогер', 'blogger', '', '2015-04-07 09:35:56', '2015-04-07 09:35:56');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_06_18_174055_install_ulogin', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1),
('2015_03_17_143929_create_password_reminders_table', 1),
('2015_03_24_075501_add_users_fields', 1),
('2015_03_26_073123_create_posts_table', 1),
('2015_03_26_080317_create_posts_views_table', 1),
('2015_03_26_080327_create_posts_likes_table', 1),
('2015_03_26_080525_create_posts_comments_table', 1),
('2015_03_27_131308_create_posts_tags_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'dictionaries', 1, 0, '2015-04-07 09:35:56', '2015-04-07 09:35:56'),
(2, 'pages', 1, 1, '2015-04-07 09:35:56', '2015-04-07 09:35:56'),
(3, 'galleries', 1, 2, '2015-04-07 09:35:56', '2015-04-07 09:35:56'),
(4, 'seo', 1, 3, '2015-04-07 09:35:56', '2015-04-07 09:35:56'),
(5, 'catalog', 1, 4, '2015-04-07 09:35:56', '2015-04-07 09:35:56'),
(6, 'system', 1, 127, '2015-04-07 09:35:56', '2015-04-07 09:35:56');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sysname` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_version_of_index` (`version_of`),
  KEY `pages_slug_index` (`slug`),
  KEY `pages_type_id_index` (`type_id`),
  KEY `pages_publication_index` (`publication`),
  KEY `pages_start_page_index` (`start_page`),
  KEY `pages_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `version_of`, `name`, `slug`, `sysname`, `template`, `type_id`, `publication`, `start_page`, `order`, `settings`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Главная страница', 'glavnaya-stranica', 'glavnaya-stranica', 'index', NULL, 1, 1, NULL, '{"new_block":0}', '2015-04-07 09:49:34', '2015-04-07 09:49:34'),
(2, NULL, 'Fashion', 'fashion', 'fashion', 'category-section', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-15 09:39:55', '2015-04-15 09:39:55'),
(3, NULL, 'Beauty', 'beauty', 'beauty', 'category-section', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-15 09:40:51', '2015-04-15 09:40:51'),
(4, NULL, 'LifeStyle', 'lifestyle', 'lifestyle', 'category-section', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-15 09:41:53', '2015-04-15 09:41:53'),
(5, NULL, 'О проекте', 'about', 'about', 'about', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-15 09:53:08', '2015-04-15 09:53:08'),
(7, NULL, 'Связаться с нами', 'contacts', 'contacts', 'contacts', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-15 09:53:46', '2015-04-15 09:53:46');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_blocks_page_id_index` (`page_id`),
  KEY `pages_blocks_slug_index` (`slug`),
  KEY `pages_blocks_order_index` (`order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_blocks_meta_block_id_index` (`block_id`),
  KEY `pages_blocks_meta_language_index` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_meta_page_id_index` (`page_id`),
  KEY `pages_meta_language_index` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `pages_meta`
--

INSERT INTO `pages_meta` (`id`, `page_id`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', NULL, '2015-04-07 09:49:34', '2015-04-07 09:49:34'),
(2, 2, 'ru', NULL, '2015-04-15 09:39:55', '2015-04-15 09:39:55'),
(3, 3, 'ru', NULL, '2015-04-15 09:40:51', '2015-04-15 09:40:51'),
(4, 4, 'ru', NULL, '2015-04-15 09:41:53', '2015-04-15 09:41:53'),
(5, 5, 'ru', NULL, '2015-04-15 09:53:08', '2015-04-15 09:53:08'),
(7, 7, 'ru', NULL, '2015-04-15 09:53:46', '2015-04-15 09:53:46');

-- --------------------------------------------------------

--
-- Структура таблицы `password_reminders`
--

DROP TABLE IF EXISTS `password_reminders`;
CREATE TABLE IF NOT EXISTS `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_reminders_email_index` (`email`),
  KEY `password_reminders_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '999',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `photos_gallery_id_index` (`gallery_id`),
  KEY `photos_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `title`, `order`, `created_at`, `updated_at`) VALUES
(1, '1429099673_66647136.jpg', '0', '', 999, '2015-04-15 09:07:53', '2015-04-15 09:07:53');

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `category_id` int(10) unsigned DEFAULT '0',
  `publish_at` date DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `photo_id` int(10) unsigned DEFAULT NULL,
  `photo_title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '0',
  `in_index` tinyint(1) unsigned DEFAULT '0',
  `in_section` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `category_id`, `publish_at`, `title`, `content`, `photo_id`, `photo_title`, `gallery_id`, `publication`, `in_index`, `in_section`, `created_at`, `updated_at`) VALUES
(1, 4, 7, '2015-04-15', 'Новый пост', '<p>\n	<strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\n</p>', 1, 'Платье ZARA, 3 500 руб.', 1, 1, 0, 0, '2015-04-15 09:03:50', '2015-04-15 09:08:08');

-- --------------------------------------------------------

--
-- Структура таблицы `posts_comments`
--

DROP TABLE IF EXISTS `posts_comments`;
CREATE TABLE IF NOT EXISTS `posts_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `content` text COLLATE utf8_unicode_ci,
  `rating` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `posts_likes`
--

DROP TABLE IF EXISTS `posts_likes`;
CREATE TABLE IF NOT EXISTS `posts_likes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `posts_tags`
--

DROP TABLE IF EXISTS `posts_tags`;
CREATE TABLE IF NOT EXISTS `posts_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned DEFAULT '0',
  `tag_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `posts_views`
--

DROP TABLE IF EXISTS `posts_views`;
CREATE TABLE IF NOT EXISTS `posts_views` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_mod_gallery_module_index` (`module`),
  KEY `unit_id` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `unit_id` (`module`),
  KEY `seo_module_index` (`module`),
  KEY `seo_unit_id_index` (`unit_id`),
  KEY `seo_language_index` (`language`),
  KEY `seo_url_index` (`url`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `module`, `unit_id`, `language`, `title`, `description`, `keywords`, `url`, `h1`, `created_at`, `updated_at`) VALUES
(1, 'Page', 1, 'ru', 'Главная страница', '', '', NULL, '', '2015-04-07 09:49:34', '2015-04-07 09:49:34'),
(2, 'Page', 2, 'ru', 'Раздел "Fashion"', '', '', NULL, 'Fashion', '2015-04-15 09:39:55', '2015-04-15 09:39:55'),
(3, 'Page', 3, 'ru', 'Раздел "Beauty"', '', '', NULL, 'Beauty', '2015-04-15 09:40:51', '2015-04-15 09:40:51'),
(4, 'Page', 4, 'ru', 'Раздел "LifeStyle"', '', '', NULL, 'LifeStyle', '2015-04-15 09:41:53', '2015-04-15 09:41:53'),
(5, 'Page', 5, 'ru', 'О проекте', '', '', NULL, 'О проекте', '2015-04-15 09:53:08', '2015-04-15 09:53:08'),
(7, 'Page', 7, 'ru', 'Связаться с нами', '', '', NULL, 'Связаться с нами', '2015-04-15 09:53:46', '2015-04-15 09:53:46');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('0fcc0f93e37f56d9a65d23554cb610448a984dcb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN3pXWkhJV3dsVVJDSGlrQWR6elJ2bnlwaENBWGhiQWtsbE0xYVdYWCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MjkxMDIwNjA7czoxOiJjIjtpOjE0MjkxMDIwNjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1429102063),
('5a17df007218cd992e2872fe9bf3e60a452aa497', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUdUSFFVbnNqaHk4RUxoUUcxam9jdGVBc2Z4Q1ZZdUREa3V5c3BJRiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MjkwOTUyODE7czoxOiJjIjtpOjE0MjkwOTUyODE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1429095284),
('671e62f11d533592da5041c08fee1a2f0d43f1b1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTFdUN2FGQktENGczTmpETk5LRmJYbE1WV1NseVVNckxhUGhKM05qdyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MjkxMDE1MDk7czoxOiJjIjtpOjE0MjkxMDE1MDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1429101512),
('a4af86072ba44643413c4fd2c607065b426d77a7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieVA4a2VsUVNnMmpsa1NVVkprY0Q3ZXAwbVJ6QjFVaWh0Q085TzVuRCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MjkxMDEyNTE7czoxOiJjIjtpOjE0MjkxMDEyNTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1429101253),
('e22a87aedcf2bad8cd589c90ace97b61707ec476', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRnhuVjdIdlJRY3hlS052STE5dURLeDNYeHR2Zk5aWWl1cEtZVm9ubSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIyIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQyOTEwMjU4MjtzOjE6ImMiO2k6MTQyOTA5MDE5MztzOjE6ImwiO3M6MToiMCI7fX0=', 1429102583),
('fb725b159b05f1d6683215f3a8a182591068ea22', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVmhQRE5TSVE3cVNtZGNkYWNVb1dPd3FiRWdvVnRnUjBHNmZKSHhlNiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MjkxMDIzNjU7czoxOiJjIjtpOjE0MjkxMDIzNjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1429102368),
('fbfe3df3124a3d58b76638b091491c3cee01acbe', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ3c5MDVZQ0l2UlNvbUVUTWliR0xXUTBZZUxBRmRaM1dlS1NDUWY5OSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MjkwOTkxNzQ7czoxOiJjIjtpOjE0MjkwOTkxNzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1429099176);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `name` (`module`),
  KEY `settings_module_index` (`module`),
  KEY `settings_name_index` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `module`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, '', 'language', 'ru', '2015-04-07 09:35:56', '2015-04-07 09:35:56');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `name` (`module`),
  KEY `storages_module_index` (`module`),
  KEY `storages_name_index` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `storages`
--

INSERT INTO `storages` (`id`, `module`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'menu', 'categories_menu', '{"title":"\\u0420\\u0430\\u0437\\u0434\\u0435\\u043b\\u044b \\u0441\\u0430\\u0439\\u0442\\u0430","nesting_level":"1","container":"%elements%","element_container":"%element%","element":"<a href=\\"%url%\\"%attr%>%text%<\\/a>","active_class":"active","items":{"1":{"text":"Fashion","title":"","type":"page","page_id":"2","id":"1","active_regexp":""},"2":{"text":"Beauty","title":"","type":"page","page_id":"3","id":"2","active_regexp":""},"3":{"text":"LifeStyle","title":"","type":"page","page_id":"4","id":"3","active_regexp":""}},"order":"[{\\"id\\":1},{\\"id\\":2},{\\"id\\":3}]"}', '2015-04-15 09:44:12', '2015-04-15 09:50:42'),
(2, 'menu_placement', 'menu_placement', '{"main_menu":"main_menu","categories_menu":"categories_menu"}', '2015-04-15 09:44:12', '2015-04-15 09:51:10'),
(3, 'menu', 'main_menu', '{"title":"\\u0413\\u043b\\u0430\\u0432\\u043d\\u043e\\u0435 \\u043c\\u0435\\u043d\\u044e","nesting_level":"1","container":"<ul>%elements%<\\/ul>","element_container":"<li%attr%>%element%<\\/li>","element":"<a href=\\"%url%\\"%attr%>%text%<\\/a>","active_class":"active","items":{"1":{"text":"\\u041e \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0435","title":"","type":"page","page_id":"5","id":"1","active_regexp":""},"2":{"text":"\\u0421\\u0432\\u044f\\u0437\\u0430\\u0442\\u044c\\u0441\\u044f \\u0441 \\u043d\\u0430\\u043c\\u0438","title":"","type":"page","page_id":"7","id":"2","active_regexp":""}},"order":"[{\\"id\\":1},{\\"id\\":2}]"}', '2015-04-15 09:51:10', '2015-04-15 09:55:13');

-- --------------------------------------------------------

--
-- Структура таблицы `ulogin`
--

DROP TABLE IF EXISTS `ulogin`;
CREATE TABLE IF NOT EXISTS `ulogin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `network` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `identity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `nickname` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `photo_big` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `bdate` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `sex` tinyint(4) NOT NULL,
  `profile` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `uid` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `token_secret` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `verified_email` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ulogin_identity_unique` (`identity`),
  KEY `ulogin_user_id_foreign` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `ulogin`
--

INSERT INTO `ulogin` (`id`, `user_id`, `network`, `identity`, `email`, `first_name`, `last_name`, `nickname`, `country`, `city`, `photo`, `photo_big`, `bdate`, `sex`, `profile`, `uid`, `access_token`, `token_secret`, `verified_email`, `created_at`, `updated_at`) VALUES
(1, 4, 'facebook', 'http://www.facebook.com/100001912017351', 'vkharseev@gmail.com', 'Владимир', 'Харсеев', '', '', '', 'http://graph.facebook.com/100001912017351/picture?type=square', 'http://graph.facebook.com/100001912017351/picture?type=large', '', 0, 'http://www.facebook.com/100001912017351', '', '', '', 0, '2015-04-15 07:57:32', '2015-04-15 07:57:32');

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `uploads_mime1_index` (`mime1`),
  KEY `uploads_mime2_index` (`mime2`),
  KEY `uploads_module_index` (`module`),
  KEY `uploads_unit_id_index` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `brand` tinyint(1) unsigned DEFAULT '0',
  `about` text COLLATE utf8_unicode_ci,
  `blogpicture` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blogname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inspiration` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `links` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_login` tinyint(1) unsigned DEFAULT '1',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `brand`, `about`, `blogpicture`, `blogname`, `phone`, `inspiration`, `site`, `links`, `location`, `birth`, `first_login`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Разработчик', '', 'developer@lookbook.ru', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '$2y$10$bp7xHs6T3VlMbuYmUYNlS.nNExaLcB8yqAp9sUX5R5spl3ZJzVQ/y', '', '', '', 0, 'cJAs8BC1C3gjheAOuJm4hMNEbwE42gqmmup2CTH3t5SQwE3woankUXG7fFgK', '2015-04-07 09:35:55', '2015-04-07 09:41:17'),
(2, 2, 'Администратор', '', 'admin@lookbook.ru', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '$2y$10$bp7xHs6T3VlMbuYmUYNlS.nNExaLcB8yqAp9sUX5R5spl3ZJzVQ/y', '', '', '', 0, 'OjxeTrUD8cvmVrw8NKAMl4vr8NgRMo5xDyy1R0bUwQCTMsvo7lhk1sJr0YeV', '2015-04-07 09:35:55', '2015-04-15 07:57:23'),
(3, 3, 'Модератор', '', 'moder@lookbook.ru', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '$2y$10$bp7xHs6T3VlMbuYmUYNlS.nNExaLcB8yqAp9sUX5R5spl3ZJzVQ/y', '', '', '', 0, 'Q5FxpgLekh6byzxIiQxhAkNXEeHOyUX7GWGirjB4owBNC0c2YO203ZoSoVnG', '2015-04-07 09:35:55', '2015-04-14 17:22:20'),
(4, 4, 'Владимир Харсеев', '', 'vkharseev@gmail.com', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '$2y$10$lZ3T6wx6rOgHRMMn5r/DdeEHpJ4bPoyw6fzTnKd4Cbt8W3QFxa.Wy', '', '', NULL, NULL, 'jVLxFqPWIr4eS7VdeR4zWik75QShSPviWGFxCMPQYDLy1GZgQu3xf32Ub0r3', '2015-04-15 07:57:32', '2015-04-15 09:08:54');

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `ulogin`
--
ALTER TABLE `ulogin`
  ADD CONSTRAINT `ulogin_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
